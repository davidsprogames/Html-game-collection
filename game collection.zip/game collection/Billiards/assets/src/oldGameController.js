
function playGame():void {
	
	resetShotVars();
	gameRunning = true;
	stage.addEventListener(Event.ENTER_FRAME, gameLoop);
}



function gameLoop(e:Event):void {
	
	if(gameRunning == true){
		
		
		
		//process mePlay functions
		if (gameInfo.turn == "player") {
			//shotReset is set to false when the ball is struck, and set to true at the end of resetVars, the very last thing that happens after the shot is played and rulings are made.  This is different from shotRunning which is true only whilst the balls are moving.  So shotReset == true can be used for the pre-shot stuff (aiming etc.)
			if(shotReset == true){
				placeMyCueBall();
				setSpin();
				aim();
				setPower();
				fineTuneUpdate();
				strikeMyBall();
				//updateCountdown();
			}
			checkMyShotOver();
			
		}else {
			gameInfo.aiHadTurn = true; //for the trophy awarded for winning without the opponent having a turn
			if(shotReset == true){
				aiPlaceCueBall();
				aiFindCalculatedShots();
				aiTestShot();
				playBreakShot();
			}
			checkYourShotOver();
			
		}
		
		//both players
		if (shotRunning == true) {
			phys.updatePhysics();
			renderScreen();
		}
	
	}
	
	
}


	
	
	


function applyRulings():void {
	
	
	
	//called after each shot is over, and all balls are static.
	//these rulings are the same functions regardless of who's turn.
	
	
	
	if (rulingsApplied == false && shotRunning == false) {
		
		//trace("applying rulings");
		
		preventQuit = true;
		
		rulingsApplied = true;
		
		//each of the following fouls will override the previous ones.
		checkForMiss();
		checkIllegalContact();
		checkForScratch();
		
		
		
		
		checkPots(); //need to check even if foul was committed in case 8 ball was illegally potted
		
		
		checkCushionContacts(); //has to come after checkPots because if a ball is potted, this is irrelevant.
		
		
		
		if(gameInfo.mode != "practice"){
			if (gameInfo.fouled == true) {
				
				trace("foul committed:");
				
				if (gameInfo.trial == false) {
					
					showFoulMessage();
					cueBallInHand = true;
					
					
					//if break off shot, rerack
					if (gameInfo.shotNum == 1) {
						gameRunning = false;
						gameInfo.rerack = true;
					}
					
				}else {
					gameInfo.shotRating = -1;
				}
			}else {
				//no foul occured, so theoretically there is no chance of a rerack - we can reset rerack and lastBreaker here.
				if (gameInfo.trial == false) {
					gameInfo.lastBreaker = "none";
					gameInfo.rerack = false;
					clearMessage();
				}
			}
		}
		
		
		
		if(gameRunning == true){ //prevents coming here in the event of rerack, in which case gameRunning is set to false
			//check trophies
			if (gameInfo.fouled == false && gameInfo.mode != "practice") {
				if(gameInfo.kiss == true){
					gameInfo.kisses ++;
				}
				if(gameInfo.combo == true){
					gameInfo.combos ++;
				}
				if(gameInfo.carom == true){
					gameInfo.caroms ++;
				}
				if(gameInfo.bank == true){
					gameInfo.banks ++;
				}
				if (gameInfo.kick == true) {
					gameInfo.kicks ++;
				}
			}
			
			//check to see if all object balls have been potted, in which case end the game
			if (gameInfo.mode == "practice") {
				var ballActive = false;
				for (var n:uint = 1; n < ballArray.length; n ++) {
					if (ballArray[n].active == true) {
						ballActive = true;
					}
				}
				if (ballActive == false) {
					gameInfo.gameOver = true;
				}
			}
			
			if (gameInfo.gameOver == false) {
				
				if (gameInfo.trial == false && gameInfo.mode != "practice") {
					setNextTargetType();
					checkWhosTurn();
				}
				resetShotVars();
			}else {
				
				//game is over - show results
				trace("game over");
				gameRunning = false;
				showGameOver();
				
			}
		}
		
		
		
		
		preventQuit = false;
		
	}
	
	if (gameInfo.rerack == true) {
		preventQuit = true;
		setTimeout(rerackBalls, 3000);
	}
	
}

function rerackBalls():void {
	
	gameInfo.lastBreaker = gameInfo.turn;
	fade();
	setTimeout(rerackPart2, 500);
	
	function rerackPart2():void{
		cleanUp();
		initGame();
	}
}

function showFoulMessage():void {
	
	if (gameInfo.clearMessage) {
		clearTimeout(gameInfo.clearMessage);
		gameInfo.clearMessage = null;
	}
	
	if(gameInfo.turn == "npc"){
		showMessage("FOUL: " + npcArray[gameInfo.npc].name + " " + gameInfo.foulMessage);
	}else {
		showMessage("FOUL: " + userData.playerName + " " + gameInfo.foulMessage);
		trace("showing foul message: " + gameInfo.foulMessage);
	}
	
	//gameInfo.clearMessage = setTimeout(clearMessage, 3000);
	
}

function clearMessage():void {
	
	if(gui){
		showMessage("");
	}
}


function checkIllegalContact():void {
	
	//first contact of cue ball needs to match with gameInfo.playerTargetType / gameInfo.npcTargetType
	for (var n:uint = 0; n < ballArray[0].contactArray.length; n ++) {
		var contact = ballArray[0].contactArray[n];
		if (contact.type == "ball") {
			var targetID = contact.target.id;
			var targetType:String;
			if (gameInfo.turn == "player") {
				targetType = gameInfo.playerTargetType;
			}else {
				targetType = gameInfo.npcTargetType;
			}
			if (targetType == "ANY" || targetType == "SOLIDS" || targetType == "STRIPES") {
				if (targetID == 8) {
					//8 ball was struck first
					gameInfo.fouled = true;
					gameInfo.foulMessage = "struck the wrong ball first";
				}
			}
			if (targetType == "SOLIDS") {
				if (targetID > 7) {
					//0 to 7 are the solids, 8 is 8 ball, so anything over 7 is not a solid
					gameInfo.fouled = true;
					gameInfo.foulMessage = "struck the wrong ball first";
				}
				
			}
			if (targetType == "STRIPES") {
				if (targetID < 9) {
					//9 to 15 are the stripes
					gameInfo.fouled = true;
					gameInfo.foulMessage = "struck the wrong ball first";
				}
				
			}
			if (targetType == "8 BALL") {
				if (targetID != 8) {
					//8 ball was not hit
					gameInfo.fouled = true;
					gameInfo.foulMessage = "struck the wrong ball first";
				}
				
			}
			break;
			//no need to check for any further contacts after the first one
		}
	}
	
	
}

function checkCushionContacts():void {
	
	//on the break, if no object ball is potted, 4 object balls need to touch the cushions after the initial cue ball contact
	//on other shots, if no ball is potted, at least 1 ball needs to touch the cushion after the first cue ball contact
	
	if (gameInfo.ballsPotted == 0 && gameInfo.fouled == false) {
		if (gameInfo.shotNum == 1) {
			//break off shot
			trace("checking cushions on break shot");
			var firstContact:Boolean = false;
			var counter:int = 0;
			for (var n:int = 1; n < ballArray.length; n ++) {
				//cycle through all object balls and check if they had any cushion contacts.  
				
				var ball = ballArray[n];
				var cushionContact = false;
				if (ball.active == true) {
					for (var c:uint = 0; c < ball.contactArray.length; c ++) {
						
						var contact = ball.contactArray[c];
						
						if (contact.type == "line" || contact.type == "vertex") {	
							cushionContact = true;
							break;
							//no need to check for any further cushion contacts for this ball
						}
					}
				}
				if (cushionContact == true) {
					counter ++;
					//trace("balls hitting cushions: " + counter);
				}
			}
			
			if (counter < 4) {
				gameInfo.fouled = true;
				gameInfo.foulMessage = " failed to make 4 balls hit the cushions on the break";
			}
			
		}else {
			//after the break, 1 ball needs to hit a cushion after first contact (could be the cue ball)
			var cushionContact2 = false;
			var firstContact:Boolean = false;
			for (var n2:int = 0; n2 < ballArray.length; n2 ++) {
				//cycle through all balls and check if they had any cushion contacts. 
				//for cue ball (n2 == 0) it needs to have hit a ball first
				
				var ball2 = ballArray[n2];
				
				if (ball2.active == true) {
					for (var c2:uint = 0; c2 < ball2.contactArray.length; c2 ++) { //error throw here - undefined term
						
						var contact2 = ball2.contactArray[c2];
						
						if (n2 == 0) {
							if(contact2.type == "ball"){
								firstContact = true;
							}
						}
						if (firstContact == true || n2 > 0) {
							//if the ball is an object ball, or if it is a cue ball then check if it has collided with another ball
							if (contact2.type == "line" || contact2.type == "vertex") {	
								cushionContact2 = true;
								break;
								//no need to check for any further contacts
							}
						}
					}
					if (cushionContact2 == true) {
						break; //and no need to check any more balls
					}
				}
				
			}
			if (cushionContact2 == false) {
				gameInfo.fouled = true;
				trace("no cushion contact");
				gameInfo.foulMessage = " failed to make a ball hit a cushion after the first contact with the cue ball";
			}
		}
	}
	
	
}

function checkForScratch():void {
	
	//scratches are set in contact listener as soon as they happen - gameInfo.scratched has been set to true.
	//trace("checking scratch");
	if(gameInfo.scratched == true){
		//trace("cue ball in pocket");
		gameInfo.fouled = true;
		gameInfo.foulMessage = "potted the cue ball";
		//note - cueBallInHand is set in applyRulings, although not for practice mode, so do it here
		if (gameInfo.mode == "practice") {
			cueBallInHand = true;
		}
	}
	
	
}

function checkForMiss():void {
	
	//take a look at the cue ball's contact array, and check that it hit at least one other ball
	var miss = true;
	var ball = ballArray[0];
	for (var n:int = 0; n < ball.contactArray.length; n ++){
		var contact = ball.contactArray[n];
		if (contact.collisionType == "ball") {
			miss = false;
			break;
		}
	}
	
	if (miss == true) {
		gameInfo.foulMessage = "missed the balls";
		gameInfo.fouled = true;
	}
	
}



function checkPots():void {
	
	
	//trace("checking for pots");
	
	//the only possibility of a foul is if the 8 ball is potted illegally.
	//if the 8 ball is potted legally, the game is won
	//if a ball of targetType is potted, the players turn is extended, otherwise the turn is ended
	//if the targetType is "ANY" and one or more balls are potted of the same type, and it's not the break off shot, the targetTypes for both players can be set
	
	//cycle through each ball (except cue ball, we have already checked that for scratched) to see if it has been potted.
	
	var firstType:String;
	var nextType:String;
	gameInfo.ballsPottedSameType = true;
	
	for (var n:uint = 1; n < ballArray.length; n ++) {
		var ball = ballArray[n];
		//trace(ball);
		for (var c:uint = 0; c < ball.contactArray.length; c ++) {
			
			var contact = ball.contactArray[c];
			//trace(contact.type);
			if (contact.type == "pocket") {
				//ball was potted
				if(gameInfo.trial == false){
					trace("ball potted")
				}
				
				gameInfo.ballsPotted ++;
				
				var targetType:String;
				if (gameInfo.turn == "npc") {
					targetType = gameInfo.npcTargetType;
				}else {
					targetType = gameInfo.playerTargetType;
				}
				
				//firstly check if 8 ball was potted
				if (ball.id == 8 && gameInfo.mode != "practice") {
					if (targetType == "8 BALL") {
						//8 ball was the target, and was potted - so game is won
						trace("game won");
						
						
						if (gameInfo.trial == true) {
							gameInfo.shotRating = 1;
						}else {
							gameInfo.gameOver = true;
							gameInfo.winner = gameInfo.turn;
							
						}
						
					}
					if (targetType != "8 BALL" || gameInfo.fouled == true) {
						
						//8 ball was illegally potted - game is lost
						
						if (gameInfo.trial == true) {
							gameInfo.shotRating = -1.5;
						}else{
							gameInfo.gameOver = true;
							trace("game lost");
							if(gameInfo.turn == "npc"){
								gameInfo.winner = "player";
							}else {
								gameInfo.winner = "npc";
							}
						}
					}
				}
				
				//trophy for potting a ball on the break off shot
				if (gameInfo.fouled == false && gameInfo.shotNum == 1 && gameInfo.turn == "player" && userData.trophies[2] == false){
					userData.trophies[2] = true;
					newTrophy = true;
					saveSO();
				}
				
				if(gameInfo.fouled == false && ball.id != 8){
				
					
					//check whether all balls potted were of same type - this is used in setNextTargetType
					if (gameInfo.ballsPotted == 1) {
						//this is the first ball potted - store its type
						if (ball.id > 8) {
							firstType = "STRIPES";
						}
						if (ball.id < 8) {
							firstType = "SOLIDS";
						}
						gameInfo.typesPotted = firstType;
					}
					
					if (gameInfo.ballsPotted > 1) {
						if (ball.id > 8) {
							nextType = "STRIPES";
						}
						if (ball.id < 8) {
							nextType = "SOLIDS";
						}
						
						if (nextType != firstType) {
							gameInfo.ballsPottedSameType = false;
							gameInfo.typesPotted = "";
						}
					}
					
					
					
					if (targetType == "STRIPES" && ball.id > 8 || targetType == "SOLIDS" && ball.id < 8 || targetType == "ANY" && ball.id != 8) {
						//9 to 15 are the stripes, 1 to 7 are solids. 8 is the id of the 8 ball
						//player potted correct ball.  Doesn't matter what else happens or when - the turn is extended
						
						if (gameInfo.trial == true) {
							gameInfo.shotRating += 0.1;
						}
						if (gameInfo.trial == false) {
							gameInfo.turnExtended = true;	
							trace("turn extended");
						}
						
						
					}
				}
				
			}
		}
	}
	if (gameInfo.ballsPotted == 0 && gameInfo.trial == false) {
		gameInfo.ballsPottedSameType = false;
		gameInfo.typesPotted = "";
	}
	
	
	
}

function setNextTargetType():void {
	
	//if the table is still open, check whether a group of balls has been determined
	trace ("set next target type?");
	
	var targetType:String;
	if (gameInfo.turn == "npc") {
		targetType = gameInfo.npcTargetType;
	}else {
		targetType = gameInfo.playerTargetType;
	}
	
	if (targetType == "ANY" && gameInfo.shotNum > 1 && gameInfo.ballsPottedSameType == true && gameInfo.ballsPotted > 0) {
		//can't determine group on the break off shot
		//all balls potted must be of same type for group to be determined - this is set above in checkPots()
		
		trace ("setting next target type");
		
		if (gameInfo.turn == "npc") {
			gameInfo.npcTargetType = gameInfo.typesPotted;
			if (gameInfo.npcTargetType == "STRIPES") {
				gameInfo.playerTargetType = "SOLIDS";
			}else {
				gameInfo.playerTargetType = "STRIPES";
			}
			
			
		}else {
			gameInfo.playerTargetType = gameInfo.typesPotted;
			if (gameInfo.playerTargetType == "STRIPES") {
				gameInfo.npcTargetType = "SOLIDS";
			}else {
				gameInfo.npcTargetType = "STRIPES";
			}
		}
		
		
		
	}
	
	//check if 8 ball is the target.  This happens if there are none of the current target balls left.  Usually this will mean there are no stripes or solids left, but it's possible for the table to remain open right up until the 8 ball is on, so the previous target could theoretically be "ANY"
	
	//on rare occassions, it's conceivable that at the end of a turn, his opponent's target is set as the 8 ball at that time - this would happen if for example a player sinks his opponents last ball (legally or illegally).  For this reason, don't just check for the player whos turn it is, check for both
	
	var stripesRemaining = 0;
	var solidsRemaining = 0;
	for (var n:uint = 1; n < ballArray.length; n ++) {
		var ball = ballArray[n];
		if(ball.active == true){
			if (ball.id < 8) {
				solidsRemaining ++;
			}
			if (ball.id > 8) {
				stripesRemaining ++;
			}
		}
	}
	
	//npc first
	if (gameInfo.npcTargetType == "STRIPES" || gameInfo.npcTargetType == "ANY") {
		if (stripesRemaining == 0) {
			gameInfo.npcTargetType = "8 BALL";
			trace("stripes remaining = 0");
		}
	}
	if (gameInfo.npcTargetType == "SOLIDS" || gameInfo.npcTargetType == "ANY") {
		if (solidsRemaining == 0) {
			gameInfo.npcTargetType = "8 BALL";
			trace("solids remaining = 0");
		}
	}
	//and then player
	if (gameInfo.playerTargetType == "STRIPES" || gameInfo.playerTargetType == "ANY") {
		if (stripesRemaining == 0) {
			gameInfo.playerTargetType = "8 BALL";
			trace("stripes remaining = 0");
		}
	}
	if (gameInfo.playerTargetType == "SOLIDS" || gameInfo.playerTargetType == "ANY") {
		if (solidsRemaining == 0) {
			gameInfo.playerTargetType = "8 BALL";
			trace("solids remaining = 0");
		}
	}
	
	//updateGUI
	gui.target1.text = gameInfo.playerTargetType;
	gui.target2.text = gameInfo.npcTargetType;
	
	
}





function checkWhosTurn():void {
	
	trace("should we switch turns?");
	
	
	
	if (gameInfo.turnExtended == false || gameInfo.fouled == true) {
		trace("switching turns");
		if(gameInfo.turn == "player") {
			gameInfo.turn = "npc"
			gui.arrow1.gotoAndStop(1);
			gui.arrow2.gotoAndStop(2);
			gui.playerAvatarBox.bg.gotoAndStop(1);
			gui.npcAvatarBox.bg.gotoAndStop(2);
		}else {
			gameInfo.turn = "player";
			gui.arrow1.gotoAndStop(2);
			gui.arrow2.gotoAndStop(1);
			gui.playerAvatarBox.bg.gotoAndStop(2);
			gui.npcAvatarBox.bg.gotoAndStop(1);
		}
	}
	
}

function resetShotVars():void {
	
	//this is called before the game begins, and is also the last thing called at the end of each shot, unless the game is over, in which case it is called from cleanUp(), although that's probably unnecessary.
	
	
	
	//tuning.visible = false;
	
	gameInfo.fouled = false;
	gameInfo.foulMessage = "";
	gameInfo.ballsPotted = 0;
	gameInfo.turnExtended = false;
	gameInfo.ballsPottedSameType = false;
	gameInfo.typesPotted = "";
	gameInfo.scratched = false;
	gameInfo.settingPower = false;
	
	//trophies
	gameInfo.kiss = false;
	gameInfo.combo = false;
	gameInfo.carom = false;
	gameInfo.bank = false;
	gameInfo.kick = false;
	
	if (gameInfo.trial == false) {
		//this is the end of an actual shot
		gameInfo.foundCalculatedShots = false;
		gameInfo.foundRandomShots = false;
		
	}
	
	
	
	
	fouled = false;
	
	upKeyDown = false;
	downKeyDown = false;
	leftKeyDown = false;
	rightKeyDown = false;
	upKey2Down = false;
	downKey2Down = false;
	leftKey2Down = false;
	rightKey2Down = false;
	spaceKeyDown = false;
	shiftKeyDown = false;
	
	
	//cleanWidget(); //done in strikeMyBall
	storedMouseY = false;
	cue.x = - ballRadius * 2 * physScale;
	cue.shadow.x = cue.x;
	//cueCanvas.rotation = 0;
	if(gameInfo.trial == false){
		cueCanvas.x = gameCanvas.x + ballArray[0].position.x * physScale;
		cueCanvas.y = gameCanvas.y + ballArray[0].position.y * physScale;
	}
	
	//reset variables at the beginning of each shot
	for (var b:uint = 0; b < ballArray.length; b ++) {
		ballArray[b].lastCollisionObject = null;
		ballArray[b].firstContact = false;
		ballArray[b].contactArray = new Array();
		
	}
	
	//shotRunning = false; already set to false when all balls come to rest
	mouseOverStrike = false;
	tuningLeft = false;
    tuningRight = false;
	preventAim = false;
	
	
	//findNextTargets();
	
	gui.powerMeter._mask.height = 0;
	gui.powerMeter.cue.y = 5;
	
	
	
	if (gameInfo.turn == "player") {
		
		//player's turn is next (we always come through here after who's turn has been decided).
		
		ballArray[0].mc.visible = true;
		
		//power = gui.power.mask.height * 20;
		gui.powerMeter._mask.height = 0;
		gui.powerMeter.cue.y = 5;
		
		if (cueBallInHand == true) {
			
			allowPlace = true;
			ballArray[0].active = true;
			
			tuning.visible = false;
			ballArray[0].shadow1.visible = true;
			ballArray[0].mc.visible = true;
			
			ballArray[0].position.x = tableTop.mouseX / physScale;
			ballArray[0].position.y = tableTop.mouseY / physScale;
			renderScreen();
			
		}else{
			allowPlace = false;
			
		}
		
		
		//show target balls
		for (var n:uint = 1; n < ballArray.length; n ++) {
			var ball = ballArray[n];
			if(ball.active == true){
				if (ball.targetType == gameInfo.playerTargetType || gameInfo.playerTargetType == "ANY" && ball.targetType != "8 BALL") {
					ball.marker.visible = true;
					ball.marker.gotoAndPlay(1);
					ball.marker.x = ball.mc.x;
					ball.marker.y = ball.mc.y;
				}
			}
		}
	
		
	}else {
		
		
		if (cueBallInHand == true) {
			allowPlace = true;
			ballArray[0].active = true;
			ballArray[0].shadow1.visible = true;
			ballArray[0].mc.visible = true;
			 
		}
		
	}
	
	if (gameInfo.turn == "npc" || gameInfo.mode == "practice") {
		//make sure all markers are hidden if it's not the player's turn next (or if in practice mode)
		for (var n:uint = 1; n < ballArray.length; n ++) {
			var ball = ballArray[n];		
			ball.marker.stop();
			ball.marker.visible = false;
			ball.marker.x = ball.mc.x;
			ball.marker.y = ball.mc.y;
		}
	}
	
	if (gameInfo.turn == "player" && cueBallInHand == false) {
		power = 4000;  //reset to medium amount for aiming guide
		updateAimingGuide(); 
		//trace("reset power");
	}
	
	if (gameInfo.turn == "npc" && cueBallInHand == false) {
		cueCanvas.visible = true;
	}
	
	
	shotReset = true;
	
	gui.spinSetter.crosshair.x = 0;
	gui.spinSetter.crosshair.y = 0;
	
	
}

function findNextTargets():void {
	
	//set bonus/required ball - set this as the lowest numbered ball.  
	if (bonusBallOn == true || requiredBallOn == true) {
		
		currentTarget = 15;
		for (var n:uint = 1; n < ballArray.length; n ++) {
			
			var ball = ballArray[n];
			
			//reset properties from previous shots
			
			
			//find lowest value ball remaining
			if (ball.active == true) {
				if (ball.id < currentTarget) {
					currentTarget = ball.id;
				}
			}
		}
		
		//find next lowest target
		if(showNextTarget == true){
			if (ballsRemaining > 1) {
				nextTarget = 15;
				
				for (n = 1; n < ballArray.length; n ++) {
					ball = ballArray[n];
					
					//find second lowest value ball remaining
					if (ball.active == true) {
						if (ball.id > currentTarget && ball.id < nextTarget) {
							nextTarget = ball.id;
						}
					}
				}
			}
		}
		
	}
}
