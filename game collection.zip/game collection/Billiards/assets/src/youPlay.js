import com.Vector2D;

function placeYourCueBall(cueBallPositionX:Number, cueBallPositionY:Number):void {
	
	//this is assuming that the place cueball and strike ball data are received in the correct order from the server.  If they aren't, this is going to screw things up badly - need to confirm that order is always preserved and if not need to apply some sort of sequence stamping and carry out events in correct order.
	
	if (myTurn == false) {
		
		ballArray[0].position.x = cueBallPositionX;
		ballArray[0].position.y = cueBallPositionY;
		
		//to do: show cueball mc in correct place - may want to tween to it's position and only allow strikemyball to execute once tween is completed.
		renderScreen();
	}
	
	cueBallInHand = false;
	
}


function strikeYourBall(vx:Number, vy:Number, s:Number, e:Number):void {
	
	if (myTurn == false) {
		shotReset = false;
		shotNum ++;
		gameInfo.shotNum ++;
		
		rulingsApplied = false;
		shotRunning = true;
		ballArray[0].screw = s;
		ballArray[0].english = e;
		ballArray[0].velocity = new Vector2D(vx, vy);
		ballArray[0].ySpin = -ballArray[0].english * ballArray[0].velocity.magnitude / 300;
		if (ballArray[0].ySpin > 20) {
			ballArray[0].ySpin = 20;
		}
		if (ballArray[0].ySpin < -20) {
			ballArray[0].ySpin = -20;
		}
		if(gameInfo.trial == false){
			var volume = ballArray[0].velocity.magnitude / 6000;
			if (volume > 1) {
				volume = 1;
			}
			if (volume < 0.3) {
				volume = 0.3;
			}
			Sound.Play("cue", volume);
		
			cueCanvas.rotation = (180 / Math.PI) * Math.atan2(vy, vx);
			TweenLite.to(cue, 0.5, { x: (power / 600), ease:Quad.easeOut } );
			TweenLite.to(cue.shadow, 0.5, { x: (power / 600), ease:Quad.easeOut } );
			TweenLite.to(cueCanvas, 1, { delay: 1.5, alpha: 0, onComplete:hideCueCanvas } );
			
			cueTweenComplete = false;
			
			function hideCueCanvas():void {
					cueCanvas.visible = false;
					cueCanvas.alpha = 1;
					cueTweenComplete = true;
			}
		}
		
		
	}else {
		//something has gone badly wrong if a shot was received during my turn, but should probably deal with it here in case.  Basically, who's turn it is is in dispute and game should probably be abandoned.
	}
}

function checkYourShotOver():void {
	
	if(shotRunning == true){
		var ballsMoving:Boolean = false;
		for (var n:uint = 0; n < ballArray.length; n ++) {
			var ball:Object = ballArray[n];
			if (ball.velocity.magnitude > 0) {
				ballsMoving = true;
			}
		}
		if (ballsMoving == false) {
			shotRunning = false;
			applyRulings();
		}
	}

	
	
}



function verifyYourPositions(e:Event):void {
	
	if(verificationReceived == true){
		
		verificationReceived = false;
		removeEventListener(Event.ENTER_FRAME, verifyYourPositions);
		
		var total:Number = 0;
		for (var b:uint = 0; b < ballArray.length; b ++) {
			var ball:Object = ballArray[b];
			total += Maths.fixNumber((ball.position.x + ball.position.y) * physScale);
		}
		total = Maths.fixNumber(total * 10000);
		debug.textField.appendText("pos: " + String(total) + "\n");
		
		
		//opponents turn - incoming value
		if (receivedVerificationValue == total) {
			debug.textField.appendText("Clients in sync\n");
		}else {
			debug.textField.appendText("Warning: clients out of sync. Received value: " + String(receivedVerificationValue) + " Calculated value: " + String(total) + "\n");
			//send request to opponent to send all position data
			//notify server - this shouldn't be happening very often, if at all, and we need to keep track of how often it does
		}
		
		//switchTurns();
		
	}
	
}