(function(){
	
var secretKey = "ACTIVE_PLAYPHONE_SECRETKEY";

document.addEventListener("deviceready",
	function() {
		if(typeof(Playphone) == "undefined"){return;}
		Playphone.initialize(secretKey,function(e){console.log(e)})
	}, false
);

})();
