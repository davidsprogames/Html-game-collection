(function(){

var dbClickForExit = false;

document.addEventListener("deviceready",
	function() {
		document.addEventListener("backbutton", onBackKeyDown, false);
	}, false
);

function onBackKeyDown(e) {
	e.preventDefault();
	if(!dbClickForExit){
		//reset in case fail
		setTimeout(function(){dbClickForExit = false;},4000);
		//ask
		if(typeof(window.plugins.toast) === "undefined"){return;}
		window.plugins.toast.show('Press Back again to Exit', 'short', 'bottom', 
			function(a){if(a === "OK"){dbClickForExit = true;}else if(a.event === "hide"){dbClickForExit = false;}},
			function(b){navigator.app.exitApp();}
		);
	}else{
		//leave
		navigator.app.exitApp();
	}
}

}());