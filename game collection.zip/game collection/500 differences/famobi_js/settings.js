var appSettings = {
	fg_package_id: 'find-500-differences',
	adDebugMode: !!false,
	ios: {
		id: ''
	},
	android: {
		id: '',
		debuggable: 'undefined', // needed for collections
		packageId: 'undefined', // needed for collections
		version: 'undefined' // needed for collections
	},
	i18n: {
		language: 'de',
		locale: 'de_DE'
	},
	environment: 'undefined', // needed for collections
	showUpdateInterval: 'undefined', // needed for collections
	url: {
		feed: 'undefined' // needed for collections
	},
	auth: {
		feed: null // needed for collections
	}
};